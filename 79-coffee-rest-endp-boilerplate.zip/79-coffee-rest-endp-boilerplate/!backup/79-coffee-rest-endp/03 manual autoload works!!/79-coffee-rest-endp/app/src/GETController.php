<?php

declare(strict_types=1);

class GETController
{
/*   public function constructor()
   {
      print 
   }
*/}