<?php
// namespace Framework\Utils;
declare(strict_types=1);


// require_once __DIR__ . '/config-app.php';

function dump_nice_header(string $p_headerString)
{
   printf('<p style="margin-top: 2rem">%s</p>', $p_headerString);
}

function dump_nice($p_variable, bool $p_isExit = true)
{
   print '<pre>';
   if (gettype($p_variable)==='array')
      print_r($p_variable);
   else
      var_dump($p_variable);
   print '</pre>';

   if ($p_isExit)
      die;
}

/**
 * l means "to live" :-)
 */
function dump_nice_l($p_variable)
{
   dump_nice($p_variable,false);
}

/**
 * Refactor it later using modern approach to error handling in PHP
 * set_event_handler etc
 */
function defaultCatchBlockHandler(\Exception $ex)
{
   dump_nice_l('[!] Exception: ' . $ex->getMessage());
   $errMessage = sprintf('Ошибка: %s' . PHP_EOL .  'Код ошибки: %d' . PHP_EOL,
      $ex->getMessage(),
      $ex->getCode()
   );
   file_put_contents(\APP_CONST::ERROR_LOG_FILENAME, $errMessage, FILE_APPEND | LOCK_EX);
}