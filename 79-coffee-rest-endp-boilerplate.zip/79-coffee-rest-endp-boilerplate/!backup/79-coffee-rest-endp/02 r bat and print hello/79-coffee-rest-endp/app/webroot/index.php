<?php

declare(strict_types=1);

print "Hello Coffee Way!";