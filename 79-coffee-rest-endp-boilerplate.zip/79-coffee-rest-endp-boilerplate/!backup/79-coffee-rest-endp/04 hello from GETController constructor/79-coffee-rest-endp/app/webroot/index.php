<?php

declare(strict_types=1);

require_once __DIR__ . '/../src/bootstrap.php';

// print "Hello Coffee Way!";

// dump_nice_header('Hello! :-)');

$GETContr = new GETController();