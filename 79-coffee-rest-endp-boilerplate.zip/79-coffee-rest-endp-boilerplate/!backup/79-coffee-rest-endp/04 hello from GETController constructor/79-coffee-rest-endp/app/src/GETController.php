<?php

declare(strict_types=1);

class GETController
{
   public function __construct()
   {
      printf('Hello from %s::%s!! :-)', __CLASS__, __FUNCTION__);
   }
}